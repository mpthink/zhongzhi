<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title></title>
    <link rel="stylesheet" type="text/css" href="__PUBLIC__/css/admincp.css" />

    <!-- dialog -->
    <link rel="stylesheet" href="__PUBLIC__/js/jquery/themes/redmond/jquery.ui.all.css">
    <script src="__PUBLIC__/js/jquery/jquery-1.7.1.js"></script>
    <script src="__PUBLIC__/js/jquery/external/jquery.bgiframe-2.1.2.js"></script>
    <script src="__PUBLIC__/js/jquery/ui/jquery.ui.core.js"></script>
    <script src="__PUBLIC__/js/jquery/ui/jquery.ui.widget.js"></script>
    <script src="__PUBLIC__/js/jquery/ui/jquery.ui.mouse.js"></script>
    <script src="__PUBLIC__/js/jquery/ui/jquery.ui.button.js"></script>
    <script src="__PUBLIC__/js/jquery/ui/jquery.ui.draggable.js"></script>
    <script src="__PUBLIC__/js/jquery/ui/jquery.ui.position.js"></script>
    <script src="__PUBLIC__/js/jquery/ui/jquery.ui.dialog.js"></script>
    <script src="__PUBLIC__/js/jquery/ui/jquery.ui.resizable.js"></script>
    <!-- dialog -->

    <!-- datepicker -->
    <!--<script src="__PUBLIC__/js/jquery/ui/jquery.ui.widget.js"></script>-->
    <script src="__PUBLIC__/js/jquery/ui/jquery.ui.datepicker.js"></script>
    <script src="__PUBLIC__/js/jquery/ui/i18n/jquery.ui.datepicker-zh-CN.js"></script>
    <script src="__PUBLIC__/js/jquery/ui/jquery.effects.core.js"></script>
    <!-- datepicker -->

    <!-- autocomplete -->
    <!--<script src="__PUBLIC__/js/jquery/ui/jquery.ui.core.js"></script>
    <script src="__PUBLIC__/js/jquery/ui/jquery.ui.widget.js"></script>
    <script src="__PUBLIC__/js/jquery/ui/jquery.ui.position.js"></script>-->
    <script src="__PUBLIC__/js/jquery/ui/jquery.ui.autocomplete.js"></script>
    <style>
        .ui-autocomplete-category {
            font-weight: bold;
            padding: .2em .4em;
            margin: .8em 0 .2em;
            line-height: 1.5;
            color:#2E6E9E;
        }
    </style>
    <!-- autocomplete -->

</head>
<body>
<div class="container">


    <table>
        <tr>
            <td><h3>库存统计 &nbsp;&nbsp;&nbsp;&nbsp;</h3></td>
            <td>
                <input class="btn" type="button" value="查询"  onclick="toSearch()"/>&nbsp;&nbsp;&nbsp;&nbsp;
            </td>

            <td>
                <form action="__URL__/exportStore" method="post">
                    <input name="in_sellerunit" type="hidden" id="in_sellerunit" value="<?php echo $in_sellerunit;?>" size="30" />
                    <input name="in_prodname" type="hidden" id="in_prodname" value="<?php echo $in_prodname;?>" size="30" />
                    <input name="in_store" type="hidden" id="in_store" value="<?php echo $in_store;?>" size="30" />
                    <input name="in_date_start" type="hidden" id="in_date_start" value="<?php echo $in_date_start;?>" size="30" />
                    <input name="in_date_end" type="hidden" id="in_date_end" value="<?php echo $in_date_end;?>" size="30" />
                    <input name="in_status_time" type="hidden" id="in_status_time" value="<?php echo $in_status_time;?>" size="30" />
                    <input name="in_quality" type="hidden" id="in_quality" value="<?php echo $in_quality;?>" size="30" />
                    <input class="btn" type="submit" value="Excel导出" />
                </form>
            </td>
        </tr>
    </table>


    <div class="mainbox">
        <form action="" method="post">
            <table class="datalist fixwidth">
                <tr>
                    <th>品名规格</th>
                    <th>类别</th>
                    <th>质量类别</th>
                    <th>数量</th>
					<th>体积</th>
                    <?php if($_SESSION['user']['user_type']==1||$_SESSION['user']['user_type']==4){ ?>
                    <th>装卸成本单价</th>
                    <th>装卸收入单价</th>
                    <?php } ?>

                    <th>客户单位</th>
                </tr>
                <?php echo $temp1."<br>";?>
                <?php echo $temp2."<br>";?>


                <?php foreach($list as $key=>$row){ ?>
                <tr>
                    <td style="text-align:center">
                        <!--<a href="__URL__/filter/iss_prod/<?php echo $row["iss_prod"]; ?>"><?php echo $row["prod_name"]; ?></a>-->
                        <?php echo $row["prod_name"]; ?>
                    </td>
                    <td style="text-align:center">
                        <!--<a href="__URL__/filter/iss_cate/<?php echo $row["iss_cate"]; ?>"><?php echo $row["pdca_name"]; ?>-->
                        <?php echo $row["pdca_name"]; ?>
                    </td>

                    <td style="text-align:center">
                        <!-- <a href="__URL__/filter/iss_quality/<?php echo $row["iss_quality"]; ?>"><?php echo $row["iss_quality"]; ?>-->
                        <?php echo $row["iss_quality"]; ?>
                    </td>
                    <td style="text-align:center"><?php echo $row["allcount"]; ?></td>
					<td style="text-align:center"><?php echo $row["allcount"]*$row["prod_volume"]; ?></td>
                    <?php if($_SESSION['user']['user_type']==1||$_SESSION['user']['user_type']==4){ ?>
                    <td style="text-align:center"><?php echo $row["prod_price"]; ?></td>
                    <td style="text-align:center"><?php echo $row["prod_realprice"]; ?></td>
                    <?php } ?>


                    <td style="text-align:center"><?php echo $row["ism_sellerunit"]; ?></td>
                </tr>
                <?php } ?>
                <tr>
                    <td colspan="2"></td>
                    <td align="center">合计：</td>
                    <td align="center"><?php echo $count; ?></td>
                    <td colspan="4"></td>
                </tr>
                <tr class="nobg">
                    <td colspan="8" align="center"><?php echo $page; ?></td>
                </tr>
            </table>
        </form>
    </div>
</div>

<div id="dialog" title="库存查询" style="display:none">
    <br><br>
    <table width="100%" border="0" align="left" class="p_table2">
        <tr>
            <td height="35" align="right">客户单位： </td>
            <td align="left"><input name="ism_sellerunit" type="text" id="ism_sellerunit" size="28" style='color:#CCC' value="请输入关键字或空格" onfocus="clearTip(this)" onblur='fillTip(this)'/></td>
            <td align="right">制单日期：</td>
            <td align="left">从&nbsp;<input name="ism_date_start" type="text" class="textfield01" id="ism_date_start" size="10" />&nbsp;到&nbsp;<input name="ism_date_end" type="text" class="textfield01" id="ism_date_end" size="10" /></td>
        </tr>
        <tr>
            <td height="35" align="right">品名规格：</td>
            <td align="left"><input name="iss_prodname" type="text" id="iss_prodname" size="28" value='请输入关键字或空格' style='color:#CCC' onfocus='clearTip(this)'  onblur='fillTip(this)'/></td>
            <td align="right">仓库： </td>
            <td align="left"><input name="iss_store" type="text" id="iss_store" size="28" /></td>
        </tr>
        <tr>
            <td height="35" align="right">质量类别：</td>
            <td align="left">
                <select name="iss_quality" id="iss_quality">
                    <option value=''>--请选择--</option>
                </select>
            </td>
            <td align="right">勾单日期：</td>
            <td align="left"><input name="ism_status_time" type="text" class="textfield01" id="ism_status_time" size="10" /></td>
        </tr>
    </table>
</div>

<script language="JavaScript" src="__PUBLIC__/js/tpl/storecount_index.js" type="text/javascript"></script>
<!-- layout::Public:footer::120 -->