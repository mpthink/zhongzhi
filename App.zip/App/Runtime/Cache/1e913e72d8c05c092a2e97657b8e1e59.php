<?php if (!defined('THINK_PATH')) exit();?></body>
</html>