<?php return array('URL_MODEL'=>3,
'DB_TYPE'=>'mysql',
'DB_HOST'=>'localhost',
'DB_NAME'=>'cang7',
'DB_USER'=>'root',
'DB_PWD'=>'123456',
'DB_PORT'=>'3306',
'DB_PREFIX'=>'twms_',
'DB_FIELDS_CACHE' =>false,
'PAGE_SIZE'=>15,
    'APP_STATUS' => 'debug',
    // 'SHOW_PAGE_TRACE' =>true,
'INDEX_NOTICE_PAGE_SIZE'=>8);
?>
